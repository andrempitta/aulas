
curso = 'Programação em Python: Essencial'


def funcao2():
    return curso

